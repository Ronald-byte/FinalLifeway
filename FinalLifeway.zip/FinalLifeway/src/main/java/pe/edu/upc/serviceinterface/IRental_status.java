package pe.edu.upc.serviceinterface;

import java.util.List;

import pe.edu.upc.entity.Rental_status;

public interface IRental_status {
	public List<Rental_status> listar();
}
