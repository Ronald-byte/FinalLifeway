package pe.edu.upc.daointerface;

import java.util.List;

import pe.edu.upc.entity.Rental_status;

public interface Rental_statusDAO {
	public List<Rental_status> listar();
}
