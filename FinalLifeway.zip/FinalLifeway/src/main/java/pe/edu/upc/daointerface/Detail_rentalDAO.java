package pe.edu.upc.daointerface;

import java.util.List;

import pe.edu.upc.entity.Detail_rental;

public interface Detail_rentalDAO {
	public List<Detail_rental> listar();
}
