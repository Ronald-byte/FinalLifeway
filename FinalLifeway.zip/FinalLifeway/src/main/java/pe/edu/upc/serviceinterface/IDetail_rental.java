package pe.edu.upc.serviceinterface;

import java.util.List;

import pe.edu.upc.entity.Detail_rental;

public interface IDetail_rental {
	public List<Detail_rental> listar();
}
